package com.ludoduo.game;

import android.app.*;import android.os.*;import android.graphics.*;import android.graphics.drawable.GradientDrawable;import android.view.*;import android.widget.*;import android.media.*;import java.io.*;import java.net.*;import java.util.*;

public class MainActivity extends Activity {
    static final int PORT=5050;
    GameView board; TextView status, ipText; ServerThread server; ToneGenerator tone;
    @Override public void onCreate(Bundle b){super.onCreate(b); tone=new ToneGenerator(AudioManager.STREAM_MUSIC,85); build(); server=new ServerThread(); server.start();}
    TextView label(String s,float z){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(z);return t;}
    void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(12,8,12,8);root.setBackgroundColor(Color.rgb(7,26,51));
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=label("LUDO DUO",24);title.setTypeface(null,1);head.addView(title,new LinearLayout.LayoutParams(0,58,1));
        status=label("● Controller waiting",12);status.setTextColor(Color.rgb(120,220,140));head.addView(status,new LinearLayout.LayoutParams(-2,58));root.addView(head);
        ipText=label("Game phone IP: "+localIp()+"   •   Port 5050",12);ipText.setTextColor(Color.LTGRAY);ipText.setGravity(Gravity.CENTER);root.addView(ipText,new LinearLayout.LayoutParams(-1,34));
        board=new GameView();root.addView(board,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bottom=new LinearLayout(this);bottom.setGravity(Gravity.CENTER);Button roll=new Button(this);roll.setText("🎲  ROLL DICE");roll.setTextSize(16);roll.setOnClickListener(v->board.roll(false));bottom.addView(roll,new LinearLayout.LayoutParams(-1,58));root.addView(bottom);setContentView(root);
    }
    String localIp(){try{for(Enumeration<NetworkInterface> en=NetworkInterface.getNetworkInterfaces();en.hasMoreElements();){NetworkInterface ni=en.nextElement();for(Enumeration<InetAddress> a=ni.getInetAddresses();a.hasMoreElements();){InetAddress x=a.nextElement();String s=x.getHostAddress();if(!x.isLoopbackAddress()&&s.indexOf(':')<0)return s;}}}catch(Exception ignored){}return "192.168.x.x";}
    void sound(int type){try{tone.startTone(type==1?ToneGenerator.TONE_PROP_BEEP:type==2?ToneGenerator.TONE_PROP_ACK:ToneGenerator.TONE_PROP_PROMPT,type==1?120:180);}catch(Exception ignored){}}
    class ServerThread extends Thread{ServerSocket ss;public void run(){try{ss=new ServerSocket(PORT);while(!isFinishing()){Socket s=ss.accept();new Client(s).start();}}catch(Exception ignored){}}}
    class Client extends Thread{Socket s;Client(Socket x){s=x;}public void run(){try{BufferedReader r=new BufferedReader(new InputStreamReader(s.getInputStream()));String line;while((line=r.readLine())!=null){final String m=line.trim();runOnUiThread(()->handle(m));}}catch(Exception ignored){}}}
    void handle(String m){try{if(m.equals("PING")){status.setText("● Controller connected");return;}String[] p=m.split("=");if(p.length==2){char c=p[0].charAt(0);int n=Integer.parseInt(p[1]);board.setController(c,n);status.setText("● Controller connected • "+c+" = "+n);status.setTextColor(Color.rgb(100,255,150));}}catch(Exception ignored){}}
    class GameView extends View{
        Paint p=new Paint(3);Random rnd=new Random();int turn=0,dice=1;boolean waiting=false;int[][] pos=new int[4][4];char[] colors={'R','G','Y','B'};int[] start={0,13,26,39};int[] col={Color.rgb(232,48,58),Color.rgb(34,190,90),Color.rgb(250,194,38),Color.rgb(39,126,238)};String[] names={"RED","GREEN","YELLOW","BLUE"};
        GameView(){super(MainActivity.this);for(int[] a:pos)Arrays.fill(a,-1);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void roll(boolean controller){if(waiting)return;dice=controller?dice:rnd.nextInt(6)+1;waiting=true;sound(1);invalidate();}
        void setController(char c,int n){int idx=-1;for(int i=0;i<4;i++)if(colors[i]==c)idx=i;if(idx<0||idx!=turn||n<1||n>6)return;dice=n;roll(true);}
        protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(13,43,77));c.drawRoundRect(5,5,w-5,h-5,24,24,p);float s=Math.min(w-24,h-130),x=(w-s)/2,y=12;drawBoard(c,x,y,s);drawInfo(c,w,y+s+5);}
        void drawBoard(Canvas c,float x,float y,float s){p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);c.drawRoundRect(x,y,x+s,y+s,20,20,p);float q=s/3;fill(c,x,y,q,q,col[0]);fill(c,x+2*q,y,q,q,col[1]);fill(c,x,y+2*q,q,q,col[2]);fill(c,x+2*q,y+2*q,q,q,col[3]);p.setColor(Color.rgb(248,248,248));c.drawRect(x+q,y,x+2*q,y+s,p);c.drawRect(x,y+q,x+s,y+2*q,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(Color.LTGRAY);for(int i=0;i<=6;i++){float a=x+q+i*q/6; c.drawLine(a,y+q,a,y+2*q,p);float b=y+q+i*q/6;c.drawLine(x+q,b,x+2*q,b,p);}p.setStyle(Paint.Style.FILL);
            Path t=new Path();int[][] tri={{1,0,2,0,1,1},{2,1,2,2,1,1},{1,2,0,2,1,1},{0,1,0,0,1,1}};for(int i=0;i<4;i++){t.reset();t.moveTo(x+tri[i][0]*q,y+tri[i][1]*q);t.lineTo(x+tri[i][2]*q,y+tri[i][3]*q);t.lineTo(x+tri[i][4]*q,y+tri[i][5]*q);t.close();p.setColor(col[i]);c.drawPath(t,p);}for(int i=0;i<4;i++)for(int j=0;j<4;j++){float[] a=homeSpot(i,j,x,y,q);drawToken(c,a[0],a[1],col[i]);}for(int i=0;i<4;i++)for(int j=0;j<4;j++)if(pos[i][j]>=0&&pos[i][j]<52){float[] a=trackSpot(pos[i][j],x,y,s);drawToken(c,a[0]+(j-1.5f)*6,a[1],col[i]);}}
        void fill(Canvas c,float x,float y,float w,float h,int z){p.setColor(z);c.drawRect(x+1,y+1,x+w-1,y+h-1,p);}
        float[] homeSpot(int k,int n,float x,float y,float q){int r=n/2,d=n%2;if(k==0)return new float[]{x+q*(.34f+.32f*d),y+q*(.34f+.32f*r)};if(k==1)return new float[]{x+2*q+q*(.34f+.32f*d),y+q*(.34f+.32f*r)};if(k==2)return new float[]{x+q*(.34f+.32f*d),y+2*q+q*(.34f+.32f*r)};return new float[]{x+2*q+q*(.34f+.32f*d),y+2*q+q*(.34f+.32f*r)};}
        float[] trackSpot(int k,float x,float y,float s){double a=2*Math.PI*k/52.0-Math.PI/2;float r=s*.39f;return new float[]{x+s/2+(float)Math.cos(a)*r,y+s/2+(float)Math.sin(a)*r};}
        void drawToken(Canvas c,float x,float y,int z){p.setStyle(Paint.Style.FILL);p.setColor(z);p.setShadowLayer(4,0,2,Color.DKGRAY);c.drawCircle(x,y,15,p);p.clearShadowLayer();p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.WHITE);c.drawCircle(x,y,15,p);p.setStyle(Paint.Style.FILL);}
        void drawInfo(Canvas c,float w,float y){p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setColor(Color.WHITE);p.setTextSize(17);c.drawText(names[turn]+" TURN",w/2,y+25,p);p.setTextSize(44);c.drawText(""+dice,w/2,y+70,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(12);c.drawText(waiting?"Tap a token area to move":"Roll the dice",w/2,y+93,p);}
        public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP||!waiting)return true;int chosen=-1;for(int j=0;j<4;j++){if(pos[turn][j]<0&&dice==6){chosen=j;break;}if(pos[turn][j]>=0&&pos[turn][j]+dice<=57){chosen=j;break;}}if(chosen>=0){if(pos[turn][chosen]<0)pos[turn][chosen]=start[turn];else pos[turn][chosen]+=dice;sound(2);}boolean again=dice==6;waiting=false;if(!again)turn=(turn+1)%4;invalidate();return true;}
    }
    @Override protected void onDestroy(){super.onDestroy();try{tone.release();}catch(Exception ignored){}try{if(server!=null&&server.ss!=null)server.ss.close();}catch(Exception ignored){}}
}
