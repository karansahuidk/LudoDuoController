# Ludo Duo Controller — Android prototype

This project contains TWO separate Android apps:
- `GameApp`: a standalone Ludo-style game. It works without the controller and listens for controller dice values over local Wi-Fi on TCP port 5050.
- `ControllerApp`: connects to the GameApp phone and lets you set a number 1–6 for Red/Green/Yellow/Blue, then sends the settings.

## Important
This is an original prototype, not a copy of Ludo King and it does not control or inject input into another company's Ludo app.

## How to build
1. Open the `LudoDuoController` folder in Android Studio.
2. Let Android Studio install/sync the Android Gradle Plugin and SDK if prompted.
3. Build/install `GameApp` on phone 1 and `ControllerApp` on phone 2.
4. Put both phones on the same Wi-Fi network.
5. On phone 1, open Game App. Find its local IP address in Android Wi-Fi details.
6. On phone 2, enter that IP and press CONNECT.
7. Set Red/Green/Yellow/Blue values and press SEND ALL SETTINGS.

## Sounds
The prototype uses Android's built-in ToneGenerator for dice/connection/move feedback, so no external sound files are required.

## Current prototype behavior
- 4 colors, 4 tokens each.
- Dice 1–6.
- Six can bring a token out.
- Basic token movement and turn handling.
- Controller can provide a fixed dice value for the current color.
- If controller is absent/disconnected, the Game App rolls randomly.

For a production release, the next pass should add full standard Ludo rules, token selection by tapping a specific token, safe squares, captures, six-roll extra turns, home lane visuals, online multiplayer, Bluetooth transport, polished sound effects, and proper reconnection/discovery.
